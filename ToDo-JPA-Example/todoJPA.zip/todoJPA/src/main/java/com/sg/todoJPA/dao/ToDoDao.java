package com.sg.todoJPA.dao;

import com.sg.todoJPA.entity.ToDo;

import java.util.List;

public interface ToDoDao {
    void addTodo(ToDo todo);
    List<ToDo> getAllTodos();
    void deleteTodo(int id);
    ToDo getToDoById(int id);
    void updateTodo(ToDo todo);
}
