package com.sg.todoJPA.dao;

import com.sg.todoJPA.entity.ToDo;
import org.springframework.stereotype.Repository;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.transaction.Transactional;
import java.util.List;

@Transactional
@Repository
public class ToDoDaoImpl implements ToDoDao{

    @PersistenceContext
    private EntityManager entityManager;

    @Override
    public void addTodo(ToDo todo) {
        entityManager.persist(todo);
    }

    @Override
    public List<ToDo> getAllTodos() {
        String query = "select id, todo, note, finished from ToDo t ";
        return (List<ToDo>) entityManager.createQuery(query).getResultList();
    }

    @Override
    public void deleteTodo(int id) {
        entityManager.remove(getToDoById(id));
    }

    @Override
    public ToDo getToDoById(int id) {
        return entityManager.find(ToDo.class, id);
    }

    @Override
    public void updateTodo(ToDo todo) {
        ToDo todoUp = getToDoById(todo.getId());

        todoUp.setTodo(todo.getTodo());
        todoUp.setNote(todo.getNote());
        todoUp.setFinished(todo.isFinished());

        entityManager.flush();  //updates the todo
    }
}
