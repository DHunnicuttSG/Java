package com.sg.todoJPA.controller;

import com.sg.todoJPA.dao.ToDoDao;
import com.sg.todoJPA.entity.ToDo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/todo")
@CrossOrigin
public class ToDoController {

    @Autowired
    private ToDoDao toDoDao;

    @GetMapping("/getalltodos")
    public ResponseEntity<List<ToDo>> getAllTodos() {
        List<ToDo> list = toDoDao.getAllTodos();
        return ResponseEntity.status(HttpStatus.OK).body(list);
    }

    @GetMapping("/find/{id}")
    public ResponseEntity<ToDo> getToDoById(@PathVariable("id") Integer id) {
        ToDo todo = toDoDao.getToDoById(id);
        return ResponseEntity.status(HttpStatus.OK).body(todo);
    }

    @PostMapping("/add")
    public ResponseEntity<String> todoAdd(@RequestBody ToDo todo) {
        toDoDao.addTodo(todo);
        return ResponseEntity.status(HttpStatus.CREATED).body("New ToDo created");
    }

    @DeleteMapping("/delete/{id}")
    public ResponseEntity<Void> deleteTodo(@PathVariable("id") Integer id) {
        toDoDao.deleteTodo(id);
        return new ResponseEntity<Void>(HttpStatus.NO_CONTENT);
    }

    @PutMapping("/update")
    public ResponseEntity<ToDo> updateTodo(@RequestBody ToDo todo) {
        toDoDao.updateTodo(todo);
        return new ResponseEntity<ToDo>(todo, HttpStatus.OK);
    }

}

