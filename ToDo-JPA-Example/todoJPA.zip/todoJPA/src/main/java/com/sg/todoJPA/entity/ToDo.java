package com.sg.todoJPA.entity;

import javax.persistence.*;

@Entity
@Table(name = "TODO")
public class ToDo {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    @Column(nullable = false, name = "todo")
    private String todo;

    @Column(nullable = false, name = "note")
    private String note;

    @Column(name = "finished")
    private boolean finished = false;

    public ToDo() {
    }

    public ToDo(String todo, String note, boolean finished) {
        //this.id = id;  Exclude auto generated id from constructor
        this.todo = todo;
        this.note = note;
        this.finished = finished;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getTodo() {
        return todo;
    }

    public void setTodo(String todo) {
        this.todo = todo;
    }

    public String getNote() {
        return note;
    }

    public void setNote(String note) {
        this.note = note;
    }

    public boolean isFinished() {
        return finished;
    }

    public void setFinished(boolean finished) {
        this.finished = finished;
    }

}
