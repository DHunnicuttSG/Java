### Assignment Status:  ![](https://github.com/theacademy/java-salary-calculator/workflows/SalaryCalculator/badge.svg)
This repository includes code and instructions for a GitHub Classroom assignment in Java

currently in use as a testing environment for git actions. DH
