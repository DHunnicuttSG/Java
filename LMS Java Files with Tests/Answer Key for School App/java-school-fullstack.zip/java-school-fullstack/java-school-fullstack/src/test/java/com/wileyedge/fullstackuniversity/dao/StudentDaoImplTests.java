package com.wileyedge.fullstackuniversity.dao;

import com.wileyedge.fullstackuniversity.model.Student;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.data.jdbc.DataJdbcTest;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.transaction.annotation.Transactional;
import java.util.List;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

@DataJdbcTest
public class StudentDaoImplTests {
    private JdbcTemplate jdbcTemplate;
    private StudentDao studentDao;

    @Autowired
    public void StudentDaoImplTest(JdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
        studentDao = new StudentDaoImpl(jdbcTemplate);
    }

    @Test
    @DisplayName("Add New Student Test")
    public void addNewStudentTest() {
        Student student = new Student();
        student.setStudentFirstName("New Student First Name");
        student.setStudentLastName("New Student Last Name");
        studentDao.createNewStudent(student);
        List<Student> newList = studentDao.getAllStudents();
        assertEquals(10, newList.size());
    }

    @Test
    @DisplayName("Get A List Of All Students")
    public void getListOfAllStudentsTest() {
        List<Student> newList = studentDao.getAllStudents();
        assertEquals(9, newList.size());
    }

    @Test
    @DisplayName("Find Student By Id")
    public void findStudentByIdTest() {
        Student student = studentDao.findStudentById(2);
        assertEquals("Steve", student.getStudentFirstName());
        assertEquals("Martin", student.getStudentLastName());
    }

    @Test
    @DisplayName("Update Student Info")
    public void updateCourseInfoTest() {
        Student student = new Student();
        student.setStudentId(1);
        student.setStudentFirstName("William");
        student.setStudentLastName("Gates");
        studentDao.updateStudent(student);
        List<Student> newList = studentDao.getAllStudents();
        int i = 0;
        for (Student st : newList) {
            if(st.getStudentFirstName().contains("William")) {
                i++;
            }
        }
        assertTrue(i != 0);
    }

    @Test
    @DisplayName("Delete Student Test")
    @Transactional
    public void deleteStudentTest() {
        //Delete Ringo Starr as he is not enrolled in any classes
        studentDao.deleteStudent(8);
        assertEquals(8, studentDao.getAllStudents().size());
    }
}
