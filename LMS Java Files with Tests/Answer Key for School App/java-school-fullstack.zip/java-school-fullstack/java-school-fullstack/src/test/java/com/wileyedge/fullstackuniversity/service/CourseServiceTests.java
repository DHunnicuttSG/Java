package com.wileyedge.fullstackuniversity.service;

import com.wileyedge.fullstackuniversity.dao.CourseDao;
import com.wileyedge.fullstackuniversity.model.Course;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;


public class CourseServiceTests {

    private CourseServiceImpl courseService;

    public CourseServiceTests() {
        CourseDao courseDao = new CourseDaoStubImpl();
        courseService = new CourseServiceImpl(courseDao);
    }

    @Test
    @DisplayName("Find Course Service test")
    public void findCourseServiceTest() {
        Course returnCourse = courseService.getCourseById(121);
        assertEquals("Service Course Stub", returnCourse.getCourseName());
    }

    @Test
    @DisplayName("Course Not Found Service Test")
    public void courseNotFoundServiceTest() {
        Course notFound = courseService.getCourseById(99);
        assertEquals("Course Not Found", notFound.getCourseName());
    }

    @Test
    @DisplayName("Update Course Service Test")
    public void updateCourseServiceTest() {
        Course course = new Course();
        course.setCourseId(121);
        course.setCourseName("Updated Course Name");
        course.setCourseDesc("Updated Course Desc");
        course.setTeacherId(10);

        Course upCourse = courseService.updateCourseData(121, course);
        course = courseService.getCourseById(121);
        assertEquals(121, course.getCourseId());
        assertEquals("Updated Course Name", course.getCourseName());
        assertEquals("Updated Course Desc", course.getCourseDesc());
        assertEquals(10, course.getTeacherId());
    }

    @Test
    @DisplayName("Course Not Updated Service Test")
    public void courseNotUpdatedServiceTest() {
        Course course = new Course();
        course.setCourseId(121);
        course.setCourseName("Updated Course Name");
        course.setCourseDesc("Updated Course Desc");
        course.setTeacherId(10);

        Course upCourse = courseService.updateCourseData(99, course);
        assertEquals("IDs do not match, course not updated", course.getCourseName());
        assertEquals("IDs do not match, course not updated", course.getCourseDesc());
    }

    @Test
    @DisplayName("Course Add Service Test")
    public void courseAddServiceTest() {
        Course course = new Course();
        course.setCourseName("New Course Name");
        course.setCourseDesc("New Course Desc");
        Course newCourse = courseService.addNewCourse(course);
        assertEquals("New Course Name", course.getCourseName());
        assertEquals("New Course Desc", course.getCourseDesc());
    }

    @Test
    @DisplayName("Course No Add Service Test")
    public void courseNoAddServiceTest() {
        Course course = new Course();
        course.setCourseName("");
        course.setCourseDesc("");
        Course newCourse = courseService.addNewCourse(course);
        assertEquals("Name blank, course NOT added", course.getCourseName());
        assertEquals("Description blank, course NOT added", course.getCourseDesc());
    }
}
