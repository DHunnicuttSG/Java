package com.wileyedge.fullstackuniversity.service;

import com.wileyedge.fullstackuniversity.dao.StudentDao;
import com.wileyedge.fullstackuniversity.model.Course;
import com.wileyedge.fullstackuniversity.model.Student;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public class StudentServiceImpl implements StudentServiceInterface {

    @Autowired
    StudentDao studentDao;

    public StudentServiceImpl(StudentDao studentDao) {
        this.studentDao = studentDao;
    }

    @Autowired
    CourseServiceImpl courseService;

    public List<Student> getAllStudents() {
        return studentDao.getAllStudents();
    }

    public Student getStudentById(int id) {
        try {
            return studentDao.findStudentById(id);
        } catch (DataAccessException ex) {
            Student student = new Student();
            student.setStudentFirstName("Student Not Found");
            student.setStudentLastName("Student Not Found");
            return student;
        }
    }

    public Student addNewStudent(Student student) {
        if (student.getStudentFirstName().toString() == "" ||
                student.getStudentLastName().toString() == "") {
            student.setStudentFirstName("First Name blank, student NOT added");
            student.setStudentLastName("Last Name blank, student NOT added");
            return student;
        } else {
            return studentDao.createNewStudent(student);
        }
    }

    public Student updateStudentData(int id, Student student) {
        if (id != student.getStudentId()) {
            student.setStudentFirstName("IDs do not match, student not updated");
            student.setStudentLastName("IDs do not match, student not updated");
            return student;
        } else {
            studentDao.updateStudent(student);
            return student;
        }
    }

    public void deleteStudentById(int id) {
        studentDao.deleteStudent(id);
    }

    public void deleteStudentFromCourse(int studentId, int courseId) {
        //check if the student exist
        Student student = getStudentById(studentId);
        //check if the course exist
        Course course = courseService.getCourseById(courseId);
        if (student.getStudentFirstName().toString() == "Student Not Found") {
            System.out.println("Student not found");
        } else if (course.getCourseName() == "Course Not Found") {
            System.out.println("Course not found");
        } else {
            studentDao.deleteStudentFromCourse(studentId, courseId);
            System.out.println("Student: " + studentId + " deleted from course: " + courseId);
        }
    }

    public void addStudentToCourse(int studentId, int courseId) {
        //check if the student exist
        Student student = getStudentById(studentId);
        //check if the course exist
        Course course = courseService.getCourseById(courseId);
        // check if
        if (student.getStudentFirstName().toString() == "Student Not Found") {
            System.out.println("Student not found");
        } else if (course.getCourseName() == "Course Not Found") {
            System.out.println("Course not found");
        } else {
            // Use try/catch to check if student already in course
            try {
                studentDao.addStudentToCourse(studentId, courseId);
                System.out.println("Student: " + studentId + " added to course: " + courseId);
            } catch (Exception ex) {
                System.out.println("Student: " + studentId + " already enrolled in course: " + courseId);
            }
        }
    }
}
