package com.wileyedge.fullstackuniversity.dao;

import com.wileyedge.fullstackuniversity.dao.mappers.CourseMapper;
import com.wileyedge.fullstackuniversity.model.Course;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.support.GeneratedKeyHolder;
import org.springframework.stereotype.Repository;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.Statement;
import java.util.List;

@Repository
public class CourseDaoImpl implements CourseDao {

    private final JdbcTemplate jdbcTemplate;

    public CourseDaoImpl(JdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
    }

    @Override
    public Course createNewCourse(Course course) {
        final String sql = "INSERT INTO " +
                "course(CourseName, CourseDesc) " +
                "VALUES (?, ?);";
        GeneratedKeyHolder keyHolder = new GeneratedKeyHolder();

        jdbcTemplate.update((Connection conn) -> {
            PreparedStatement statement = conn.prepareStatement(
                    sql,
                    Statement.RETURN_GENERATED_KEYS);
            statement.setString(1, course.getCourseName());
            statement.setString(2, course.getCourseDesc());
            return statement;
        }, keyHolder);

        course.setCourseId(keyHolder.getKey().intValue());

        return course;
    }

    @Override
    public List<Course> getAllCourses() {
        final String sql = "SELECT * FROM course";
        List<Course> courses = jdbcTemplate.query(sql, new CourseMapper());
        return courses;
    }

    @Override
    public Course findCourseById(int id) {
        final String sql = "SELECT * FROM course where cid = ?";
        Course course = jdbcTemplate.queryForObject(sql, new CourseMapper(), id);
        return course;
    }

    @Override
    public void updateCourse(Course course) {
        final String sql = "UPDATE course SET "
                + "cid = ?, "
                + "courseName = ?, "
                + "courseDesc = ?,"
                + "teacherId = ? "
                + "WHERE cid = ?;";

        jdbcTemplate.update(sql,
                course.getCourseId(),
                course.getCourseName(),
                course.getCourseDesc(),
                course.getTeacherId(),
                course.getCourseId());
    }

    @Override
    public void deleteCourse(int id) {
        final String sql = "DELETE FROM course WHERE cid = ?";
        jdbcTemplate.update(sql, id);
    }

    @Override
    public void deleteAllStudentsFromCourse(int courseId) {
        final String sql = "DELETE FROM course_student where course_id = ?";
        jdbcTemplate.update(sql, courseId);
    }
}
