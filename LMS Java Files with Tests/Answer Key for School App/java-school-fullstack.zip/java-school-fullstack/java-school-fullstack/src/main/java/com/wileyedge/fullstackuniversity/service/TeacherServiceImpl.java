package com.wileyedge.fullstackuniversity.service;

import com.wileyedge.fullstackuniversity.dao.TeacherDao;
import com.wileyedge.fullstackuniversity.model.Teacher;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.stereotype.Repository;
import java.util.List;

@Repository
public class TeacherServiceImpl implements TeacherServiceInterface {

    @Autowired
    TeacherDao teacherDao;

    public TeacherServiceImpl(TeacherDao teacherDao) {
        this.teacherDao = teacherDao;
    }

    public List<Teacher> getAllTeachers() {
        return teacherDao.getAllTeachers();
    }

    public Teacher getTeacherById(int id) {
        try {
            return teacherDao.findTeacherById(id);
        } catch (DataAccessException ex) {
            Teacher teacher = new Teacher();
            teacher.setTeacherFName("Teacher Not Found");
            teacher.setTeacherLName("Teacher Not Found");
            return teacher;
        }
    }

    public Teacher addNewTeacher(Teacher teacher) {
        if (teacher.getTeacherFName().toString() == "" ||
                teacher.getTeacherLName().toString() == "") {
            teacher.setTeacherFName("First Name blank, teacher NOT added");
            teacher.setTeacherLName("Last Name blank, teacher NOT added");
            return teacher;
        } else {
            return teacherDao.createNewTeacher(teacher);
        }
    }

    public Teacher updateTeacherData(int id, Teacher teacher) {
        if (id != teacher.getTeacherId()) {
            teacher.setTeacherFName("IDs do not match, teacher not updated");
            teacher.setTeacherLName("IDs do not match, teacher not updated");
            return teacher;
        } else {
            teacherDao.updateTeacher(teacher);
            return teacher;
        }
    }

    public void deleteTeacherById(int id) {
        teacherDao.deleteTeacher(id);
    }
}
