package com.wileyedge.fullstackuniversity.dao.mappers;

import com.wileyedge.fullstackuniversity.model.Course;
import org.springframework.jdbc.core.RowMapper;

import java.sql.ResultSet;
import java.sql.SQLException;

public class CourseMapper implements RowMapper<Course> {
    @Override
    public Course mapRow(ResultSet rs, int rowNum) throws SQLException {
        Course course = new Course();
        course.setCourseId(rs.getInt("CID"));
        course.setCourseName(rs.getString("CourseName"));
        course.setCourseDesc(rs.getString("CourseDesc"));
        course.setTeacherId(rs.getInt("TeacherId"));
        return course;
    }
}
