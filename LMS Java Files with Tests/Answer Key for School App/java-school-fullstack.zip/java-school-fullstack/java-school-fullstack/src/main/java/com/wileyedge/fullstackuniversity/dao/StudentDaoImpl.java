package com.wileyedge.fullstackuniversity.dao;

import com.wileyedge.fullstackuniversity.dao.mappers.StudentMapper;
import com.wileyedge.fullstackuniversity.model.Student;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.support.GeneratedKeyHolder;
import org.springframework.stereotype.Repository;
import javax.transaction.Transactional;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.Statement;
import java.util.List;

@Repository
public class StudentDaoImpl implements StudentDao {

    @Autowired
    private final JdbcTemplate jdbcTemplate;

    public StudentDaoImpl(JdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
    }

    @Override
    @Transactional
    public Student createNewStudent(Student student) {
        final String ADD_STUDENT = "INSERT INTO " +
                "student(FName, LName) " +
                "VALUES (?, ?);";

        GeneratedKeyHolder keyHolder = new GeneratedKeyHolder();

        jdbcTemplate.update((Connection conn) -> {
            PreparedStatement statement = conn.prepareStatement(
                    ADD_STUDENT,
                    Statement.RETURN_GENERATED_KEYS);
            statement.setString(1, student.getStudentFirstName());
            statement.setString(2, student.getStudentLastName());
            return statement;
        }, keyHolder);

        student.setStudentId(keyHolder.getKey().intValue());

        return student;
    }

    @Override
    public List<Student> getAllStudents() {
        final String sql = "Select * from student;";
        List<Student> students = jdbcTemplate.query(sql, new StudentMapper());
        return students;
    }

    @Override
    public Student findStudentById(int id) {
        final String sql = "Select * from student where sid = ?";
        Student student = jdbcTemplate.queryForObject(sql, new StudentMapper(), id);
        return student;
    }

    @Override
    public void updateStudent(Student student) {
        final String sql = "UPDATE student SET "
                + "sid = ?, "
                + "FName = ?, "
                + "LName = ? "
                + "WHERE sid = ?;";
        jdbcTemplate.update(sql, student.getStudentId(),
                student.getStudentFirstName(),
                student.getStudentLastName(),
                student.getStudentId());
    }

    @Override
    public void deleteStudent(int id) {
        final String sql = "Delete from student where sid = ?";
        jdbcTemplate.update(sql, id);
    }

    @Override
    public void addStudentToCourse(int studentId, int courseId) {
        final String sql = "INSERT INTO course_student(student_id, course_id) " +
                "VALUES (?,?)";
        jdbcTemplate.update(sql, studentId, courseId);
    }

    @Override
    public void deleteStudentFromCourse(int studentId, int courseId) {
        final String sql = "DELETE from course_student WHERE student_id = ? and " +
                "course_id = ?";
        jdbcTemplate.update(sql, studentId, courseId);
    }
}
