package com.wileyedge.fullstackuniversity.service;

import com.wileyedge.fullstackuniversity.dao.CourseDao;
import com.wileyedge.fullstackuniversity.model.Course;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public class CourseServiceImpl implements CourseServiceInterface {

    @Autowired
    CourseDao courseDao;

    public CourseServiceImpl(CourseDao courseDao) {
        this.courseDao = courseDao;
    }

    public List<Course> getAllCourses() {
        return courseDao.getAllCourses();
    }

    public Course getCourseById(int id) {
        try {
            return courseDao.findCourseById(id);
        } catch (DataAccessException ex) {
            Course course = new Course();
            course.setCourseName("Course Not Found");
            course.setCourseDesc("Course Not Found");
            return course;
        }
    }

    public Course addNewCourse(Course course) {
        if (course.getCourseName().toString() == "" ||
                course.getCourseDesc().toString() == "") {
            course.setCourseName("Name blank, course NOT added");
            course.setCourseDesc("Description blank, course NOT added");
            return course;
        } else {
            return courseDao.createNewCourse(course);
        }
    }

    public Course updateCourseData(int id, Course course) {
        if (id != course.getCourseId()) {
            course.setCourseName("IDs do not match, course not updated");
            course.setCourseDesc("IDs do not match, course not updated");
        } else {
            courseDao.updateCourse(course);
        }
        return course;
    }

    public void deleteCourseById(int id) {
        // delete students in course with id param
        courseDao.deleteAllStudentsFromCourse(id);
        courseDao.deleteCourse(id);
        System.out.println("Course ID: " + id + " deleted.");
    }
}
